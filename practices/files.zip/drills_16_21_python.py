"""Datasets for drills 16 and 21.

DRILL 16 - embedding prep
  Split each document into chunks of at most 60 words with a 15-word overlap,
  emitting (doc_id, chunk_index, chunk_text). Then drop near-duplicate chunks.
  DOC3 and DOC4 are near-identical on purpose - your dedup must catch them.

DRILL 21 - merge K sorted streams
  SORTED_STREAMS holds K already-sorted sequences. Treat each as a stream you
  consume once (do not concatenate-and-sort). Produce one fully sorted output
  with a heap, O(N log K). Duplicate values across and within streams are kept.
"""

# ============================================================
# DRILL 16 - documents to chunk and dedup
# ============================================================
DOCUMENTS = [
    {'doc_id': 'DOC1', 'text': 'Vector search returns the nearest neighbours of a query embedding. Recall depends on the index type and on how the data was chunked.'},
    {'doc_id': 'DOC2', 'text': 'An embedding model maps text to a fixed length vector. Two texts with similar meaning land close together in that vector space. The model version must stay consistent across every chunk in one index, otherwise distances are not comparable and retrieval quality drops.'},
    {'doc_id': 'DOC3', 'text': 'A data pipeline moves records from many source systems into a central store. Each source has its own schema and its own update cadence. The pipeline must be idempotent so that a re-run never double counts. It uses a high water mark per source to read only new rows. Late arriving data is held in a side path and merged once its window is complete. Schema changes are detected by comparing a version hash before each load. Failed batches are retried with backoff and a dead letter queue catches anything that fails repeatedly. Metrics on row counts and latency are emitted so operators can spot a regression early. The warehouse layer is partitioned by load date to keep scans cheap and to make backfills safe.'},
    {'doc_id': 'DOC4', 'text': 'A data pipeline moves records from many source systems into a central store. Each source has its own schema and its own update cadence. The pipeline must be repeatable so that a re-run never over counts. It uses a high water mark per source to read only new rows. Late arriving data is held in a side path and merged once its window is complete. Schema changes are detected by comparing a version hash before each load. Failed batches are retried with backoff and a dead letter queue catches anything that fails repeatedly. Metrics on row counts and latency are emitted so engineers can spot a regression early. The warehouse layer is partitioned by load date to keep scans cheap and to make backfills safe.'},
    {'doc_id': 'DOC5', 'text': 'Re embedding is required whenever a source document changes.'},
]

# ============================================================
# DRILL 21 - K independently sorted sequences
# ============================================================
SORTED_STREAMS = [
    [1, 4, 7, 12, 19, 25, 33],
    [2, 2, 8, 8, 15, 15, 30],
    [3, 9, 9, 21, 21, 21],
    [5, 11, 17, 23, 23],
    [0, 6, 10, 14, 18, 22, 26, 40],
]

def stream(seq):
    """Wrap a list as a one-pass iterator, to mimic a real stream/file cursor."""
    for x in seq:
        yield x


if __name__ == "__main__":
    print("DOCUMENTS         :", len(DOCUMENTS))
    print("longest doc words :", max(len(d["text"].split()) for d in DOCUMENTS))
    total = sum(len(s) for s in SORTED_STREAMS)
    print("SORTED_STREAMS    :", len(SORTED_STREAMS), "streams,", total, "values total")
