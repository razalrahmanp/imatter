-- ===================================================================
-- Drill 17 | point-in-time feature correctness
-- Build features for each labelled user using ONLY events strictly
-- before label_ts. Watch the 30-day window edge and the event that
-- lands exactly on a label_ts.
-- ===================================================================

DROP TABLE IF EXISTS training_labels;
CREATE TABLE training_labels (
  user_id TEXT,
  label_ts TIMESTAMP,
  churned INTEGER,
  PRIMARY KEY (user_id)
);
INSERT INTO training_labels (user_id,label_ts,churned) VALUES
  ('U1','2025-03-01 00:00:00',1),
  ('U2','2025-03-15 00:00:00',0),
  ('U3','2025-04-01 00:00:00',1),
  ('U4','2025-02-20 00:00:00',0);


DROP TABLE IF EXISTS feature_events;
CREATE TABLE feature_events (
  event_id INTEGER PRIMARY KEY,
  user_id TEXT,
  event_ts TIMESTAMP,
  event_type TEXT,
  value NUMERIC(12,2)
);
INSERT INTO feature_events (event_id,user_id,event_ts,event_type,value) VALUES
  (1,'U1','2025-01-10 09:00:00','login',0),
  (2,'U1','2025-02-01 10:00:00','purchase',200),
  (3,'U1','2025-02-20 11:00:00','login',0),
  (4,'U1','2025-02-27 12:00:00','support_ticket',0),
  (5,'U1','2025-03-05 09:00:00','login',0),
  (6,'U1','2025-04-01 09:00:00','purchase',500),
  (7,'U2','2025-01-05 09:00:00','login',0),
  (8,'U2','2025-02-10 10:00:00','purchase',150),
  (9,'U2','2025-03-01 09:00:00','login',0),
  (10,'U2','2025-03-10 14:00:00','purchase',300),
  (11,'U2','2025-03-14 18:00:00','login',0),
  (12,'U2','2025-03-15 00:00:00','login',0),
  (13,'U2','2025-03-20 09:00:00','login',0),
  (14,'U2','2025-03-25 11:00:00','purchase',100),
  (15,'U3','2025-02-15 09:00:00','login',0),
  (16,'U3','2025-03-01 09:00:00','support_ticket',0),
  (17,'U3','2025-03-20 09:00:00','login',0),
  (18,'U3','2025-04-05 09:00:00','login',0),
  (19,'U4','2025-01-01 09:00:00','login',0),
  (20,'U4','2025-02-01 10:00:00','purchase',90),
  (21,'U4','2025-02-19 18:00:00','login',0),
  (22,'U4','2025-03-01 11:00:00','purchase',400),
  (23,'U4','2025-04-01 09:00:00','login',0);

