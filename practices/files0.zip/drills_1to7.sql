-- ===================================================================
-- Data-engineering drills 1-7  | seed data
-- Tested on PostgreSQL and SQLite. MySQL-compatible DDL.
-- Timestamps are 'YYYY-MM-DD HH:MM:SS' string literals.
-- ===================================================================

DROP TABLE IF EXISTS streams;
CREATE TABLE streams (
  stream_id INTEGER PRIMARY KEY,
  user_id TEXT,
  track_id TEXT,
  artist_id TEXT,
  played_at TIMESTAMP,
  ms_played INTEGER
);
INSERT INTO streams (stream_id,user_id,track_id,artist_id,played_at,ms_played) VALUES
  (1,'u01','t101','A1','2025-01-05 09:12:00',240000),
  (2,'u02','t101','A1','2025-02-11 18:03:00',235000),
  (3,'u03','t101','A1','2025-03-20 21:40:00',238000),
  (4,'u01','t101','A1','2025-05-02 08:15:00',242000),
  (5,'u02','t101','A1','2024-06-01 10:00:00',240000),
  (6,'u03','t101','A1','2024-07-01 10:00:00',240000),
  (7,'u04','t101','A1','2024-08-01 10:00:00',240000),
  (8,'u01','t102','A1','2025-01-09 11:00:00',180000),
  (9,'u02','t102','A1','2025-02-14 12:00:00',175000),
  (10,'u05','t102','A1','2025-04-01 14:00:00',182000),
  (11,'u03','t102','A1','2025-06-06 16:00:00',179000),
  (12,'u04','t103','A1','2025-03-03 09:00:00',150000),
  (13,'u05','t103','A1','2025-08-08 09:00:00',152000),
  (14,'u02','t104','A1','2025-09-09 09:00:00',90000),
  (15,'u06','t201','A2','2025-01-15 10:00:00',200000),
  (16,'u07','t201','A2','2025-03-15 10:00:00',205000),
  (17,'u06','t201','A2','2025-07-15 10:00:00',201000),
  (18,'u07','t202','A2','2025-02-02 10:00:00',230000),
  (19,'u08','t202','A2','2025-05-05 10:00:00',228000),
  (20,'u06','t203','A2','2025-02-20 10:00:00',160000),
  (21,'u08','t203','A2','2025-06-22 10:00:00',158000),
  (22,'u09','t301','A3','2025-01-01 12:00:00',170000),
  (23,'u09','t301','A3','2025-02-01 12:00:00',171000),
  (24,'u10','t301','A3','2025-03-01 12:00:00',172000),
  (25,'u10','t301','A3','2025-04-01 12:00:00',173000),
  (26,'u09','t301','A3','2025-05-01 12:00:00',174000),
  (27,'u10','t302','A3','2025-10-10 12:00:00',95000);


DROP TABLE IF EXISTS transactions;
CREATE TABLE transactions (
  txn_id INTEGER PRIMARY KEY,
  account_id TEXT,
  txn_ts TIMESTAMP,
  amount NUMERIC(12,2),
  direction TEXT
);
INSERT INTO transactions (txn_id,account_id,txn_ts,amount,direction) VALUES
  (1,'ACC1','2025-04-01 09:00:00',500,'credit'),
  (2,'ACC1','2025-04-02 09:00:00',200,'debit'),
  (3,'ACC1','2025-04-03 09:00:00',400,'debit'),
  (4,'ACC1','2025-04-04 09:00:00',1000,'credit'),
  (5,'ACC1','2025-04-05 09:00:00',100,'debit'),
  (6,'ACC2','2025-04-01 10:00:00',1000,'credit'),
  (7,'ACC2','2025-04-02 10:00:00',300,'debit'),
  (8,'ACC2','2025-04-03 10:00:00',200,'debit'),
  (9,'ACC2','2025-04-04 10:00:00',50,'credit'),
  (10,'ACC3','2025-04-01 11:00:00',50,'debit'),
  (11,'ACC3','2025-04-02 11:00:00',500,'credit'),
  (12,'ACC3','2025-04-03 11:00:00',100,'debit'),
  (13,'ACC4','2025-04-01 12:00:00',100,'credit'),
  (14,'ACC4','2025-04-02 12:00:00',150,'debit'),
  (15,'ACC4','2025-04-03 12:00:00',300,'credit'),
  (16,'ACC4','2025-04-04 12:00:00',400,'debit');


DROP TABLE IF EXISTS health_checks;
CREATE TABLE health_checks (
  server_id TEXT,
  check_date DATE,
  status TEXT,
  PRIMARY KEY (server_id, check_date)
);
INSERT INTO health_checks (server_id,check_date,status) VALUES
  ('SRV1','2025-03-01','UP'),
  ('SRV1','2025-03-02','UP'),
  ('SRV1','2025-03-03','UP'),
  ('SRV1','2025-03-04','DOWN'),
  ('SRV1','2025-03-05','UP'),
  ('SRV1','2025-03-06','UP'),
  ('SRV1','2025-03-07','UP'),
  ('SRV1','2025-03-08','UP'),
  ('SRV1','2025-03-09','UP'),
  ('SRV1','2025-03-10','DOWN'),
  ('SRV1','2025-03-11','UP'),
  ('SRV1','2025-03-12','UP'),
  ('SRV2','2025-03-01','DOWN'),
  ('SRV2','2025-03-02','DOWN'),
  ('SRV2','2025-03-03','UP'),
  ('SRV2','2025-03-04','UP'),
  ('SRV2','2025-03-05','UP'),
  ('SRV2','2025-03-06','UP'),
  ('SRV2','2025-03-07','DOWN'),
  ('SRV2','2025-03-08','UP'),
  ('SRV2','2025-03-09','UP'),
  ('SRV2','2025-03-10','UP'),
  ('SRV2','2025-03-11','UP'),
  ('SRV2','2025-03-12','UP'),
  ('SRV3','2025-03-01','UP'),
  ('SRV3','2025-03-02','UP'),
  ('SRV3','2025-03-03','UP'),
  ('SRV3','2025-03-04','UP'),
  ('SRV3','2025-03-05','UP'),
  ('SRV3','2025-03-06','UP'),
  ('SRV3','2025-03-07','UP'),
  ('SRV3','2025-03-08','UP'),
  ('SRV3','2025-03-09','UP'),
  ('SRV3','2025-03-10','UP'),
  ('SRV3','2025-03-11','UP'),
  ('SRV3','2025-03-12','UP');


DROP TABLE IF EXISTS events;
CREATE TABLE events (
  user_id TEXT,
  event_ts TIMESTAMP,
  screen TEXT
);
INSERT INTO events (user_id,event_ts,screen) VALUES
  ('U1','2025-02-10 09:00:00','home'),
  ('U1','2025-02-10 09:10:00','search'),
  ('U1','2025-02-10 09:25:00','detail'),
  ('U1','2025-02-10 10:30:00','home'),
  ('U1','2025-02-10 10:40:00','cart'),
  ('U2','2025-02-10 14:00:00','home'),
  ('U2','2025-02-10 15:00:00','home'),
  ('U2','2025-02-10 15:05:00','search'),
  ('U2','2025-02-10 15:20:00','detail'),
  ('U2','2025-02-10 15:29:00','cart'),
  ('U2','2025-02-10 16:10:00','home'),
  ('U2','2025-02-10 16:15:00','profile'),
  ('U3','2025-02-10 08:00:00','home'),
  ('U3','2025-02-10 08:20:00','search'),
  ('U3','2025-02-10 08:45:00','detail'),
  ('U3','2025-02-10 09:10:00','checkout');


DROP TABLE IF EXISTS imports;
CREATE TABLE imports (
  row_id INTEGER PRIMARY KEY,
  email TEXT,
  full_name TEXT,
  phone TEXT,
  updated_at TIMESTAMP,
  source_system TEXT
);
INSERT INTO imports (row_id,email,full_name,phone,updated_at,source_system) VALUES
  (1,'a@mail.com','Asha R','9000000001','2025-04-10 08:00:00','CRM'),
  (2,'a@mail.com','Asha Rao','9000000002','2025-04-12 08:00:00','WEB'),
  (3,'a@mail.com','A Rao','9000000003','2025-04-08 08:00:00','BULK'),
  (4,'b@mail.com','Biju K','9000000010','2025-03-01 00:00:00','WEB'),
  (5,'b@mail.com','Biju Kumar','9000000011','2025-03-01 00:00:00','CRM'),
  (6,'c@mail.com','Chitra','9000000020','2025-01-09 00:00:00','CRM'),
  (7,'d@mail.com','Deepak','9000000030','2025-05-01 00:00:00','BULK'),
  (8,'d@mail.com','Deepak M','9000000031','2025-05-05 00:00:00','BULK'),
  (9,'e@mail.com','Elsa','9000000040','2025-02-02 00:00:00','CRM'),
  (10,'e@mail.com','Elsa P','9000000041','2025-02-10 00:00:00','CRM'),
  (11,'e@mail.com','Elsa Paul','9000000042','2025-02-15 00:00:00','WEB'),
  (12,'f@mail.com','Faisal','9000000050','2025-07-07 00:00:00','WEB'),
  (13,'g@mail.com','Gita','9000000060','2025-06-01 00:00:00','WEB'),
  (14,'g@mail.com','Gita S','9000000061','2025-06-01 00:00:00','CRM');


DROP TABLE IF EXISTS price_changes;
CREATE TABLE price_changes (
  product_id TEXT,
  new_price NUMERIC(10,2),
  effective_from DATE,
  PRIMARY KEY (product_id, effective_from)
);
INSERT INTO price_changes (product_id,new_price,effective_from) VALUES
  ('P1',100.0,'2025-01-01'),
  ('P1',120.0,'2025-03-01'),
  ('P1',150.0,'2025-06-01'),
  ('P2',50.0,'2025-02-01'),
  ('P2',60.0,'2025-05-01');


DROP TABLE IF EXISTS sales;
CREATE TABLE sales (
  sale_id INTEGER PRIMARY KEY,
  product_id TEXT,
  sold_at TIMESTAMP,
  quantity INTEGER
);
INSERT INTO sales (sale_id,product_id,sold_at,quantity) VALUES
  (1,'P1','2025-01-15 10:00:00',2),
  (2,'P1','2025-03-05 10:00:00',1),
  (3,'P1','2025-07-01 10:00:00',3),
  (4,'P2','2025-02-10 10:00:00',5),
  (5,'P2','2025-04-30 23:59:00',2),
  (6,'P2','2025-05-02 10:00:00',4),
  (7,'P1','2024-12-20 10:00:00',1),
  (8,'P2','2025-01-10 10:00:00',2),
  (9,'P1','2025-03-01 00:00:00',1),
  (10,'P2','2025-05-01 12:00:00',3);


DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
  order_id TEXT PRIMARY KEY,
  customer_id TEXT,
  order_ts TIMESTAMP
);
INSERT INTO orders (order_id,customer_id,order_ts) VALUES
  ('O1','C1','2025-05-01 10:00:00'),
  ('O2','C2','2025-05-01 12:00:00'),
  ('O3','C1','2025-05-02 08:00:00'),
  ('O4','C3','2025-05-03 09:00:00'),
  ('O5','C2','2025-05-03 15:00:00'),
  ('O6','C4','2025-05-04 11:00:00'),
  ('O7','C3','2025-05-05 06:00:00'),
  ('O8','C1','2025-05-06 20:00:00');


DROP TABLE IF EXISTS shipments;
CREATE TABLE shipments (
  shipment_id TEXT PRIMARY KEY,
  order_id TEXT,
  shipped_ts TIMESTAMP
);
INSERT INTO shipments (shipment_id,order_id,shipped_ts) VALUES
  ('S1','O1','2025-05-02 09:00:00'),
  ('S2','O2','2025-05-04 18:00:00'),
  ('S3','O3','2025-05-06 08:00:00'),
  ('S5','O5','2025-05-04 15:00:00'),
  ('S7','O7','2025-05-07 06:00:00'),
  ('S8','O8','2025-05-09 20:00:00');

