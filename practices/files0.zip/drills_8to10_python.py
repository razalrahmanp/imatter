"""Datasets for data-engineering drills 8, 9 and 10.
Import this module, or copy the structures into your solution file.
"""

# ============================================================
# DRILL 8 - access log parsing & metrics
# Each line:  IP - - [timestamp] "METHOD /path HTTP/1.1" STATUS BYTES SECONDS
# ============================================================
ACCESS_LOGS = [
    '192.168.1.10 - - [10/Apr/2025:08:00:01 +0000] "GET /home HTTP/1.1" 200 5320 0.042',
    '192.168.1.10 - - [10/Apr/2025:08:00:05 +0000] "GET /search HTTP/1.1" 200 1820 0.110',
    '10.0.0.5 - - [10/Apr/2025:08:00:09 +0000] "GET /product/55 HTTP/1.1" 200 9450 0.230',
    '192.168.1.10 - - [10/Apr/2025:08:00:12 +0000] "GET /cart HTTP/1.1" 200 2200 0.075',
    '172.16.0.9 - - [10/Apr/2025:08:00:15 +0000] "GET /missing HTTP/1.1" 404 512 0.018',
    '10.0.0.5 - - [10/Apr/2025:08:00:19 +0000] "GET /checkout HTTP/1.1" 500 880 0.640',
    '192.168.1.10 - - [10/Apr/2025:08:00:24 +0000] "GET /home HTTP/1.1" 200 5320 0.038',
    '10.0.0.5 - - [10/Apr/2025:08:00:28 +0000] "GET /product/12 HTTP/1.1" 200 7100 0.190',
    '172.16.0.9 - - [10/Apr/2025:08:00:31 +0000] "GET /old-link HTTP/1.1" 301 0 0.005',
    '192.168.1.10 - - [10/Apr/2025:08:00:35 +0000] "GET /search HTTP/1.1" 200 1900 0.097',
    '203.0.113.7 - - [10/Apr/2025:08:00:40 +0000] "GET /home HTTP/1.1" 200 5320 0.051',
    '10.0.0.5 - - [10/Apr/2025:08:00:44 +0000] "GET /api/data HTTP/1.1" 500 640 0.720',
    '192.168.1.10 - - [10/Apr/2025:08:00:48 +0000] "GET /product/9 HTTP/1.1" 200 6600 0.205',
    '172.16.0.9 - - [10/Apr/2025:08:00:52 +0000] "GET /home HTTP/1.1" 200 5320 0.060',
    '203.0.113.7 - - [10/Apr/2025:08:00:56 +0000] "GET /search HTTP/1.1" 200 1750 0.130',
    '10.0.0.5 - - [10/Apr/2025:08:01:01 +0000] "GET /missing-page HTTP/1.1" 404 512 0.022',
    '192.168.1.10 - - [10/Apr/2025:08:01:05 +0000] "GET /cart HTTP/1.1" 200 2300 0.080',
    '198.51.100.3 - - [10/Apr/2025:08:01:09 +0000] "GET /home HTTP/1.1" 200 5320 0.044',
    '10.0.0.5 - - [10/Apr/2025:08:01:13 +0000] "GET /product/77 HTTP/1.1" 200 8800 0.260',
    '172.16.0.9 - - [10/Apr/2025:08:01:18 +0000] "GET /checkout HTTP/1.1" 500 900 0.690',
    '192.168.1.10 - - [10/Apr/2025:08:01:22 +0000] "GET /home HTTP/1.1" 200 5320 0.040',
    '203.0.113.7 - - [10/Apr/2025:08:01:26 +0000] "GET /product/3 HTTP/1.1" 200 5900 0.175',
    '10.0.0.5 - - [10/Apr/2025:08:01:30 +0000] "GET /search HTTP/1.1" 200 2000 0.115',
    '198.51.100.3 - - [10/Apr/2025:08:01:34 +0000] "GET /old HTTP/1.1" 301 0 0.006',
    '192.168.1.10 - - [10/Apr/2025:08:01:39 +0000] "GET /product/41 HTTP/1.1" 200 7200 0.210',
    '172.16.0.9 - - [10/Apr/2025:08:01:43 +0000] "GET /home HTTP/1.1" 200 5320 0.049',
    '10.0.0.5 - - [10/Apr/2025:08:01:47 +0000] "GET /api/data HTTP/1.1" 200 1200 0.150',
    '203.0.113.7 - - [10/Apr/2025:08:01:51 +0000] "GET /cart HTTP/1.1" 200 2100 0.070',
    '192.168.1.10 - - [10/Apr/2025:08:01:55 +0000] "GET /search HTTP/1.1" 200 1850 0.105',
    '198.51.100.3 - - [10/Apr/2025:08:02:00 +0000] "GET /missing HTTP/1.1" 404 512 0.020',
    '10.0.0.5 - - [10/Apr/2025:08:02:04 +0000] "GET /checkout HTTP/1.1" 500 950 0.810',
    '192.168.1.10 - - [10/Apr/2025:08:02:08 +0000] "GET /home HTTP/1.1" 200 5320 0.041',
    '172.16.0.9 - - [10/Apr/2025:08:02:13 +0000] "GET /product/8 HTTP/1.1" 200 6300 0.188',
    '203.0.113.7 - - [10/Apr/2025:08:02:17 +0000] "GET /home HTTP/1.1" 200 5320 0.047',
    '10.0.0.5 - - [10/Apr/2025:08:02:21 +0000] "GET /search HTTP/1.1" 200 1950 0.099',
    '192.168.1.10 - - [10/Apr/2025:08:02:25 +0000] "GET /product/19 HTTP/1.1" 200 7700 0.225',
]

# ============================================================
# DRILL 9 - reconciliation between two sources
# Expected: only in A -> K005, K010 ; only in B -> K013, K014 ;
#           amount differs by > 0.01 -> K003, K006, K008
#           (K002 and K012 differ by < 0.01 -> must NOT be flagged)
# ============================================================
SOURCE_A = [
    {'id': 'K001', 'amount': 100.0, 'updated_at': '2025-04-01 10:00:00'},
    {'id': 'K002', 'amount': 250.5, 'updated_at': '2025-04-01 10:05:00'},
    {'id': 'K003', 'amount': 75.25, 'updated_at': '2025-04-01 10:10:00'},
    {'id': 'K004', 'amount': 500.0, 'updated_at': '2025-04-01 10:15:00'},
    {'id': 'K005', 'amount': 33.33, 'updated_at': '2025-04-01 10:20:00'},
    {'id': 'K006', 'amount': 1200.0, 'updated_at': '2025-04-01 10:25:00'},
    {'id': 'K007', 'amount': 9.99, 'updated_at': '2025-04-01 10:30:00'},
    {'id': 'K008', 'amount': 410.0, 'updated_at': '2025-04-01 10:35:00'},
    {'id': 'K009', 'amount': 88.0, 'updated_at': '2025-04-01 10:40:00'},
    {'id': 'K010', 'amount': 64.2, 'updated_at': '2025-04-01 10:45:00'},
    {'id': 'K011', 'amount': 700.0, 'updated_at': '2025-04-01 10:50:00'},
    {'id': 'K012', 'amount': 15.0, 'updated_at': '2025-04-01 10:55:00'},
]

SOURCE_B = [
    {'id': 'K001', 'amount': 100.0, 'updated_at': '2025-04-02 09:00:00'},
    {'id': 'K002', 'amount': 250.505, 'updated_at': '2025-04-02 09:05:00'},
    {'id': 'K003', 'amount': 80.25, 'updated_at': '2025-04-02 09:10:00'},
    {'id': 'K004', 'amount': 500.0, 'updated_at': '2025-04-02 09:15:00'},
    {'id': 'K006', 'amount': 1199.5, 'updated_at': '2025-04-02 09:20:00'},
    {'id': 'K007', 'amount': 9.99, 'updated_at': '2025-04-02 09:25:00'},
    {'id': 'K008', 'amount': 410.02, 'updated_at': '2025-04-02 09:30:00'},
    {'id': 'K009', 'amount': 88.0, 'updated_at': '2025-04-02 09:35:00'},
    {'id': 'K013', 'amount': 305.0, 'updated_at': '2025-04-02 09:40:00'},
    {'id': 'K014', 'amount': 42.0, 'updated_at': '2025-04-02 09:45:00'},
    {'id': 'K011', 'amount': 700.0, 'updated_at': '2025-04-02 09:50:00'},
    {'id': 'K012', 'amount': 15.009, 'updated_at': '2025-04-02 09:55:00'},
]

# ============================================================
# DRILL 10 - top-K from a very large stream
# event_stream() simulates hundreds of millions of product-id strings.
# The DISTINCT set is small (30 ids) and fits in memory; the stream does not.
# Weights are tiered so the 10 most frequent ids are deterministic.
# ============================================================
import random

_WEIGHTED = (
    [("P_top_%02d" % i, 50) for i in range(1, 11)] +   # 10 heavy hitters
    [("P_mid_%02d" % i, 8)  for i in range(1, 11)] +   # 10 mid-frequency
    [("P_low_%02d" % i, 1)  for i in range(1, 11)]     # 10 rare
)
_IDS     = [pid for pid, _ in _WEIGHTED]
_WEIGHTS = [w   for _, w in _WEIGHTED]

def event_stream(n=2_000_000, seed=42):
    """Yield n product-id strings one at a time. Do NOT call list() on this."""
    rng = random.Random(seed)
    for _ in range(n):
        yield rng.choices(_IDS, weights=_WEIGHTS, k=1)[0]


if __name__ == "__main__":
    print("ACCESS_LOGS lines :", len(ACCESS_LOGS))
    print("SOURCE_A records  :", len(SOURCE_A))
    print("SOURCE_B records  :", len(SOURCE_B))
    sample = [next(event_stream(n=5))]
    print("event_stream OK   : first 5 ->", [x for x in event_stream(n=5)])
